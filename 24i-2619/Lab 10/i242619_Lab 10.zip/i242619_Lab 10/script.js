
// Convert date text into Date objects
let parseDate = d3.timeParse("%Y-%m-%d");

// Load the CSV dataset
d3.csv("air_quality_2025.csv").then(function(data) {

    // Convert columns into correct data types
    data.forEach(function(d) {
        d.date = parseDate(d.date);
        d.pm25_city = +d.pm25_city;
        d.pm25_suburb = +d.pm25_suburb;
        d.temp_c = +d.temp_c;
    });

    // Sort data by date
    data.sort(function(a, b) {
        return a.date - b.date;
    });


    // =========================
    // TASK 1: DATASET OVERVIEW
    // =========================

    let totalRows = data.length;

    let firstDate = d3.min(data, function(d) {
        return d.date;
    });

    let lastDate = d3.max(data, function(d) {
        return d.date;
    });

    let totalDays = 365;

    let difference = totalDays - totalRows;

    console.log("Total Rows:", totalRows);
    console.log("First Date:", firstDate);
    console.log("Last Date:", lastDate);
    console.log("Days in 2025:", totalDays);
    console.log("Difference:", difference);

    d3.select("#results")
        .html(
            "<p><b>Total Rows:</b> " + totalRows + "</p>" +
            "<p><b>First Date:</b> " + firstDate.toDateString() + "</p>" +
            "<p><b>Last Date:</b> " + lastDate.toDateString() + "</p>" +
            "<p><b>Total Days in 2025:</b> " + totalDays + "</p>" +
            "<p><b>Difference:</b> " + difference + "</p>"
        );


    // =========================
    // TASK 2: DAILY CITY PM2.5
    // =========================

    // Count days above 15
    let above15 = data.filter(function(d) {
        return d.pm25_city > 15;
    }).length;

    // Count days above 75
    let above75 = data.filter(function(d) {
        return d.pm25_city > 75;
    }).length;

    // Display the counts
    d3.select("#task2-counts")
        .html(
            "Days above 15 μg/m³: " + above15 +
            " | Days above 75 μg/m³: " + above75
        );


    // Find the two highest pollution days
    let highestDays = data.slice().sort(function(a, b) {
        return b.pm25_city - a.pm25_city;
    }).slice(0, 2);


    // Chart dimensions
    let width = 900;
    let height = 450;

    let margin = {
        top: 30,
        right: 100,
        bottom: 60,
        left: 70
    };


    // Create SVG area
    let svg = d3.select("#chart-line")
        .append("svg")
        .attr("viewBox", "0 0 " + width + " " + height);


    // X scale: dates
    let x = d3.scaleTime()
        .domain(d3.extent(data, function(d) {
            return d.date;
        }))
        .range([margin.left, width - margin.right]);


    // Y scale: PM2.5 values
    let y = d3.scaleLinear()
        .domain([
            0,
            d3.max(data, function(d) {
                return d.pm25_city;
            })
        ])
        .nice()
        .range([height - margin.bottom, margin.top]);


    // Draw X axis
    svg.append("g")
        .attr("transform", "translate(0," + (height - margin.bottom) + ")")
        .call(d3.axisBottom(x));


    // Draw Y axis
    svg.append("g")
        .attr("transform", "translate(" + margin.left + ",0)")
        .call(d3.axisLeft(y));


    // X axis label
    svg.append("text")
        .attr("x", width / 2)
        .attr("y", height - 10)
        .attr("text-anchor", "middle")
        .attr("class", "axis-label")
        .text("Date");


    // Y axis label
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .attr("class", "axis-label")
        .text("PM2.5 (μg/m³)");


    // Draw reference line at 15
    svg.append("line")
        .attr("x1", margin.left)
        .attr("x2", width - margin.right)
        .attr("y1", y(15))
        .attr("y2", y(15))
        .attr("stroke", "orange")
        .attr("stroke-width", 2)
        .attr("stroke-dasharray", "6,4");


    // Label for 15
    svg.append("text")
        .attr("x", width - margin.right + 5)
        .attr("y", y(15) - 5)
        .attr("fill", "orange")
        .attr("class", "reference-label")
        .text("15 Guideline");


    // Draw reference line at 75
    svg.append("line")
        .attr("x1", margin.left)
        .attr("x2", width - margin.right)
        .attr("y1", y(75))
        .attr("y2", y(75))
        .attr("stroke", "red")
        .attr("stroke-width", 2)
        .attr("stroke-dasharray", "6,4");


    // Label for 75
    svg.append("text")
        .attr("x", width - margin.right + 5)
        .attr("y", y(75) - 5)
        .attr("fill", "red")
        .attr("class", "reference-label")
        .text("75 Interim Target");


    // Create line generator
    let line = d3.line()
        .x(function(d) {
            return x(d.date);
        })
        .y(function(d) {
            return y(d.pm25_city);
        });


    // Draw daily PM2.5 line
    svg.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", "#2468a2")
        .attr("stroke-width", 2)
        .attr("d", line);


    // Mark the two highest days
    svg.selectAll(".highest-point")
        .data(highestDays)
        .enter()
        .append("circle")
        .attr("cx", function(d) {
            return x(d.date);
        })
        .attr("cy", function(d) {
            return y(d.pm25_city);
        })
        .attr("r", 6)
        .attr("fill", "red");


    // Label the two highest days
    svg.selectAll(".highest-label")
        .data(highestDays)
        .enter()
        .append("text")
        .attr("x", function(d) {
            return x(d.date) - 5;
        })
        .attr("y", function(d, i) {
            return y(d.pm25_city) - 12 - (i * 18);
        })
        .attr("text-anchor", "end")
        .attr("fill", "red")
        .attr("class", "point-label")
        .text(function(d) {
            return d3.timeFormat("%d %b")(d.date) +
                ": " + d.pm25_city;
        });



    // =========================
    // TASK 3: CUMULATIVE UNHEALTHY DAYS
    // =========================

    // Start running total at zero
    let runningTotal = 0;

    // Go through every day
    data.forEach(function(d) {

        // Check if city pollution is above 75
        if (d.pm25_city > 75) {
            runningTotal = runningTotal + 1;
        }

        // Store the running total for this day
        d.unhealthyTotal = runningTotal;

    });

    // Display final running total in console
    console.log("Final cumulative unhealthy days:", runningTotal);

    // Chart dimensions
    let width3 = 900;
    let height3 = 450;

    let margin3 = {
        top: 30,
        right: 40,
        bottom: 60,
        left: 70
    };

    // Create SVG area
    let svg3 = d3.select("#chart-cumulative")
        .append("svg")
        .attr("viewBox", "0 0 " + width3 + " " + height3);

    // X scale: dates
    let x3 = d3.scaleTime()
        .domain(d3.extent(data, function(d) {
            return d.date;
        }))
        .range([margin3.left, width3 - margin3.right]);

    // Y scale: cumulative unhealthy days
    let y3 = d3.scaleLinear()
        .domain([
            0,
            Math.max(1, d3.max(data, function(d) {
                return d.unhealthyTotal;
            }))
        ])
        .nice()
        .range([height3 - margin3.bottom, margin3.top]);

    // Draw X axis
    svg3.append("g")
        .attr("transform", "translate(0," + (height3 - margin3.bottom) + ")")
        .call(d3.axisBottom(x3));

    // Draw Y axis
    svg3.append("g")
        .attr("transform", "translate(" + margin3.left + ",0)")
        .call(d3.axisLeft(y3));

    // X axis label
    svg3.append("text")
        .attr("x", width3 / 2)
        .attr("y", height3 - 10)
        .attr("text-anchor", "middle")
        .text("Date");

    // Y axis label
    svg3.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height3 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("Cumulative Unhealthy Days");

    // Create area generator
    let area3 = d3.area()
        .x(function(d) {
            return x3(d.date);
        })
        .y0(y3(0))
        .y1(function(d) {
            return y3(d.unhealthyTotal);
        });

    // Draw filled area
    svg3.append("path")
        .datum(data)
        .attr("fill", "#77aadd")
        .attr("stroke", "#2468a2")
        .attr("stroke-width", 2)
        .attr("d", area3);

    // Check that Task 3 matches Task 2
    console.log("Task 2 count above 75:", above75);
    console.log("Task 3 final total:", runningTotal);


        // =========================
    // TASK 4: CITY VS SUBURB
    // =========================

    // Chart dimensions
    let width4 = 900;
    let height4 = 450;

    let margin4 = {
        top: 40,
        right: 40,
        bottom: 60,
        left: 70
    };

    // Create SVG
    let svg4 = d3.select("#chart-comparison")
        .append("svg")
        .attr("viewBox", "0 0 " + width4 + " " + height4);

    // X scale: dates
    let x4 = d3.scaleTime()
        .domain(d3.extent(data, function(d) {
            return d.date;
        }))
        .range([margin4.left, width4 - margin4.right]);

    // Find the maximum PM2.5 value from BOTH columns
    let maxPM = d3.max(data, function(d) {
        return Math.max(d.pm25_city, d.pm25_suburb);
    });

    // Y scale: PM2.5 values
    let y4 = d3.scaleLinear()
        .domain([0, maxPM])
        .nice()
        .range([height4 - margin4.bottom, margin4.top]);

    // Draw X axis
    svg4.append("g")
        .attr("transform", "translate(0," + (height4 - margin4.bottom) + ")")
        .call(d3.axisBottom(x4));

    // Draw Y axis
    svg4.append("g")
        .attr("transform", "translate(" + margin4.left + ",0)")
        .call(d3.axisLeft(y4));

    // X axis label
    svg4.append("text")
        .attr("x", width4 / 2)
        .attr("y", height4 - 10)
        .attr("text-anchor", "middle")
        .text("Date");

    // Y axis label
    svg4.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height4 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("PM2.5 (μg/m³)");

    // Line for city readings
    let cityLine = d3.line()
        .x(function(d) {
            return x4(d.date);
        })
        .y(function(d) {
            return y4(d.pm25_city);
        });

    // Line for suburb readings
    let suburbLine = d3.line()
        .x(function(d) {
            return x4(d.date);
        })
        .y(function(d) {
            return y4(d.pm25_suburb);
        });

    // Draw city line
    svg4.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", "#2468a2")
        .attr("stroke-width", 2)
        .attr("d", cityLine);

    // Draw suburb line
    svg4.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", "#e67e22")
        .attr("stroke-width", 2)
        .attr("d", suburbLine);

    // Add legend for City
    svg4.append("line")
        .attr("x1", width4 - 180)
        .attr("x2", width4 - 150)
        .attr("y1", 20)
        .attr("y2", 20)
        .attr("stroke", "#2468a2")
        .attr("stroke-width", 3);

    svg4.append("text")
        .attr("x", width4 - 140)
        .attr("y", 24)
        .text("City");

    // Add legend for Suburb
    svg4.append("line")
        .attr("x1", width4 - 180)
        .attr("x2", width4 - 150)
        .attr("y1", 40)
        .attr("y2", 40)
        .attr("stroke", "#e67e22")
        .attr("stroke-width", 3);

    svg4.append("text")
        .attr("x", width4 - 140)
        .attr("y", 44)
        .text("Suburb");

     // =========================
    // TASK 5: MONTHLY POLLUTION LEVELS
    // =========================

    // Define the four pollution levels
    let levels = ["Low", "Moderate", "High", "Severe"];

    // Create an array for all 12 months
    let monthlyData = [];

    for (let i = 0; i < 12; i++) {
        monthlyData.push({
            month: i,
            Low: 0,
            Moderate: 0,
            High: 0,
            Severe: 0
        });
    }

    // Go through every day's reading
    data.forEach(function(d) {

        // Get the month (0 = January, 1 = February, etc.)
        let monthNumber = d.date.getMonth();

        // Assign the day to a pollution level
        if (d.pm25_city <= 35) {
            monthlyData[monthNumber].Low++;
        }
        else if (d.pm25_city <= 75) {
            monthlyData[monthNumber].Moderate++;
        }
        else if (d.pm25_city <= 150) {
            monthlyData[monthNumber].High++;
        }
        else {
            monthlyData[monthNumber].Severe++;
        }

    });

    // Print monthly counts in the console
    console.log("Task 5 monthly pollution levels:", monthlyData);

    // Chart dimensions
    let width5 = 900;
    let height5 = 450;

    let margin5 = {
        top: 40,
        right: 40,
        bottom: 70,
        left: 60
    };

    // Create SVG
    let svg5 = d3.select("#chart-levels")
        .append("svg")
        .attr("viewBox", "0 0 " + width5 + " " + height5);

    // Month names
    let monthNames = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    // X scale: months
    let x5 = d3.scaleBand()
        .domain(monthNames)
        .range([margin5.left, width5 - margin5.right])
        .padding(0.2);

    // Y scale: number of days
    let y5 = d3.scaleLinear()
        .domain([0, 31])
        .range([height5 - margin5.bottom, margin5.top]);

    // Colours from light to dark
    let colors5 = d3.scaleOrdinal()
        .domain(levels)
        .range(["#d9f0a3", "#addd8e", "#78c679", "#238443"]);

    // Create stacked data
    let stackedData = d3.stack()
        .keys(levels)(monthlyData);

    // Draw X axis
    svg5.append("g")
        .attr("transform", "translate(0," + (height5 - margin5.bottom) + ")")
        .call(d3.axisBottom(x5));

    // Draw Y axis
    svg5.append("g")
        .attr("transform", "translate(" + margin5.left + ",0)")
        .call(d3.axisLeft(y5));

    // X axis label
    svg5.append("text")
        .attr("x", width5 / 2)
        .attr("y", height5 - 15)
        .attr("text-anchor", "middle")
        .text("Month");

    // Y axis label
    svg5.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height5 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("Number of Days");

    // Draw the stacked bars
    svg5.selectAll(".level")
        .data(stackedData)
        .enter()
        .append("g")
        .attr("fill", function(d) {
            return colors5(d.key);
        })
        .selectAll("rect")
        .data(function(d) {
            return d;
        })
        .enter()
        .append("rect")
        .attr("x", function(d) {
            return x5(monthNames[d.data.month]);
        })
        .attr("y", function(d) {
            return y5(d[1]);
        })
        .attr("height", function(d) {
            return y5(d[0]) - y5(d[1]);
        })
        .attr("width", x5.bandwidth());

    // Add legend
    let legend5 = svg5.append("g")
        .attr("transform", "translate(" + (width5 - 160) + ", 45)");

    levels.forEach(function(level, i) {

        legend5.append("rect")
            .attr("x", 0)
            .attr("y", i * 25)
            .attr("width", 15)
            .attr("height", 15)
            .attr("fill", colors5(level));

        legend5.append("text")
            .attr("x", 22)
            .attr("y", i * 25 + 12)
            .text(level);

    });

    // Check the total number of recorded days in each month
    monthlyData.forEach(function(d) {
        let total = d.Low + d.Moderate + d.High + d.Severe;

        console.log(
            monthNames[d.month] + " total recorded days:",
            total
        );
    });       



        // =========================
    // TASK 6: POLLUTION HEATMAP
    // =========================

    // Names of months and weekdays
    let months6 = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ];

    let weekdays6 = [
        "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday"
    ];

    // Calculate average PM2.5 for each month and weekday
    let heatmapData = d3.rollup(
        data,
        function(days) {
            return d3.mean(days, function(d) {
                return d.pm25_city;
            });
        },
        function(d) {
            return d.date.getMonth();
        },
        function(d) {
            // Convert Sunday = 0 into Monday = 0
            return (d.date.getDay() + 6) % 7;
        }
    );

    // Chart dimensions
    let width6 = 950;
    let height6 = 500;

    let margin6 = {
        top: 60,
        right: 130,
        bottom: 60,
        left: 110
    };

    // Create SVG
    let svg6 = d3.select("#chart-heatmap")
        .append("svg")
        .attr("viewBox", "0 0 " + width6 + " " + height6);

    // X scale: weekdays
    let x6 = d3.scaleBand()
        .domain(weekdays6)
        .range([margin6.left, width6 - margin6.right])
        .padding(0.08);

    // Y scale: months
    let y6 = d3.scaleBand()
        .domain(months6)
        .range([margin6.top, height6 - margin6.bottom])
        .padding(0.08);

    // Find minimum and maximum average values
    let allAverages = [];

    heatmapData.forEach(function(weekdayMap) {
        weekdayMap.forEach(function(value) {
            allAverages.push(value);
        });
    });

    let minAverage = d3.min(allAverages);
    let maxAverage = d3.max(allAverages);

    // Colour scale
    let color6 = d3.scaleSequential()
        .domain([minAverage, maxAverage])
        .interpolator(d3.interpolateYlOrRd);

    // Draw X axis
    svg6.append("g")
        .attr("transform", "translate(0," + (height6 - margin6.bottom) + ")")
        .call(d3.axisBottom(x6));

    // Draw Y axis
    svg6.append("g")
        .attr("transform", "translate(" + margin6.left + ",0)")
        .call(d3.axisLeft(y6));

    // Draw heatmap cells
    months6.forEach(function(month, monthIndex) {

        weekdays6.forEach(function(weekday, weekdayIndex) {

            let value = heatmapData.get(monthIndex)
                ? heatmapData.get(monthIndex).get(weekdayIndex)
                : undefined;

            if (value !== undefined) {

                svg6.append("rect")
                    .attr("x", x6(weekday))
                    .attr("y", y6(month))
                    .attr("width", x6.bandwidth())
                    .attr("height", y6.bandwidth())
                    .attr("fill", color6(value))
                    .attr("stroke", "white");

                // Show average value inside each cell
                svg6.append("text")
                    .attr("x", x6(weekday) + x6.bandwidth() / 2)
                    .attr("y", y6(month) + y6.bandwidth() / 2 + 4)
                    .attr("text-anchor", "middle")
                    .attr("font-size", "10px")
                    .text(value.toFixed(1));

            }

        });

    });

    // Add colour legend
    let legend6 = svg6.append("g")
        .attr("transform", "translate(" + (width6 - 105) + "," + margin6.top + ")");

    let legendValues = 10;

    for (let i = 0; i < legendValues; i++) {

        let value = minAverage +
            (maxAverage - minAverage) * i / (legendValues - 1);

        legend6.append("rect")
            .attr("x", 0)
            .attr("y", i * 25)
            .attr("width", 18)
            .attr("height", 25)
            .attr("fill", color6(value));

    }

    // Legend labels
    legend6.append("text")
        .attr("x", 25)
        .attr("y", 10)
        .text(maxAverage.toFixed(1));

    legend6.append("text")
        .attr("x", 25)
        .attr("y", legendValues * 25)
        .text(minAverage.toFixed(1));

    // Print averages in console
    console.log("Task 6 heatmap data:", heatmapData);

    // =========================
    // TASK 7: MONTHLY RANGE AND AVERAGE
    // =========================

    // Group readings by month and calculate statistics
    let monthlyStats = d3.rollup(
        data,

        function(days) {
            return {
                min: d3.min(days, function(d) {
                    return d.pm25_city;
                }),

                max: d3.max(days, function(d) {
                    return d.pm25_city;
                }),

                mean: d3.mean(days, function(d) {
                    return d.pm25_city;
                })
            };
        },

        function(d) {
            return d3.timeMonth(d.date);
        }
    );

    // Convert grouped data into an array
    let statsArray = Array.from(
        monthlyStats,
        function(entry) {
            return {
                month: entry[0],
                min: entry[1].min,
                max: entry[1].max,
                mean: entry[1].mean
            };
        }
    );

    // Sort months chronologically
    statsArray.sort(function(a, b) {
        return a.month - b.month;
    });

    // Chart dimensions
    let width7 = 900;
    let height7 = 450;

    let margin7 = {
        top: 40,
        right: 40,
        bottom: 60,
        left: 70
    };

    // Create SVG
    let svg7 = d3.select("#chart-range")
        .append("svg")
        .attr("viewBox", "0 0 " + width7 + " " + height7);

    // X scale: months
    let x7 = d3.scaleTime()
        .domain(d3.extent(statsArray, function(d) {
            return d.month;
        }))
        .range([margin7.left, width7 - margin7.right]);

    // Y scale: PM2.5 values
    let y7 = d3.scaleLinear()
        .domain([
            0,
            d3.max(statsArray, function(d) {
                return d.max;
            })
        ])
        .nice()
        .range([height7 - margin7.bottom, margin7.top]);

    // Draw X axis
    svg7.append("g")
        .attr("transform", "translate(0," + (height7 - margin7.bottom) + ")")
        .call(
            d3.axisBottom(x7)
                .ticks(d3.timeMonth.every(1))
                .tickFormat(d3.timeFormat("%b"))
        );

    // Draw Y axis
    svg7.append("g")
        .attr("transform", "translate(" + margin7.left + ",0)")
        .call(d3.axisLeft(y7));

    // X axis label
    svg7.append("text")
        .attr("x", width7 / 2)
        .attr("y", height7 - 10)
        .attr("text-anchor", "middle")
        .text("Month");

    // Y axis label
    svg7.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height7 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("PM2.5 (μg/m³)");

    // Area between monthly minimum and maximum
    let area7 = d3.area()
        .x(function(d) {
            return x7(d.month);
        })
        .y0(function(d) {
            return y7(d.min);
        })
        .y1(function(d) {
            return y7(d.max);
        });

    // Draw shaded area
    svg7.append("path")
        .datum(statsArray)
        .attr("fill", "#a6cee3")
        .attr("opacity", 0.6)
        .attr("d", area7);

    // Line for monthly average
    let meanLine7 = d3.line()
        .x(function(d) {
            return x7(d.month);
        })
        .y(function(d) {
            return y7(d.mean);
        });

    // Draw average line
    svg7.append("path")
        .datum(statsArray)
        .attr("fill", "none")
        .attr("stroke", "#e6550d")
        .attr("stroke-width", 3)
        .attr("d", meanLine7);

    // Draw circles on average values
    svg7.selectAll(".mean-point")
        .data(statsArray)
        .enter()
        .append("circle")
        .attr("cx", function(d) {
            return x7(d.month);
        })
        .attr("cy", function(d) {
            return y7(d.mean);
        })
        .attr("r", 4)
        .attr("fill", "#e6550d");

    // Print monthly statistics
    console.log("Task 7 monthly statistics:");

    statsArray.forEach(function(d) {
        console.log(
            d3.timeFormat("%B")(d.month),
            "Minimum:", d.min.toFixed(2),
            "Maximum:", d.max.toFixed(2),
            "Average:", d.mean.toFixed(2)
        );
    });

        // =========================
    // TASK 8: 7-DAY MOVING AVERAGE
    // =========================

    // Create a map to find readings by date
    let dateMap8 = new Map();

    data.forEach(function(d) {
        dateMap8.set(+d.date, d);
    });

    // Create a complete list of dates, including missing dates
    let startDate8 = d3.timeDay.floor(data[0].date);
    let endDate8 = d3.timeDay.floor(data[data.length - 1].date);

    let totalDays8 = d3.timeDay.count(startDate8, endDate8) + 1;

    let plotData8 = [];

    for (let i = 0; i < totalDays8; i++) {

        let currentDate = d3.timeDay.offset(startDate8, i);
        let originalData = dateMap8.get(+currentDate);

        if (originalData) {
            plotData8.push({
                date: currentDate,
                pm25_city: originalData.pm25_city,
                movingAverage: null
            });
        }
        else {
            // Insert a blank entry for a missing date
            plotData8.push({
                date: currentDate,
                pm25_city: null,
                movingAverage: null
            });
        }
    }

    // Count missing dates
    let missingDays8 = plotData8.filter(function(d) {
        return d.pm25_city === null;
    }).length;

    console.log("Missing days:", missingDays8);

    // Display missing-day count on the webpage
    d3.select("#chart-moving")
        .append("p")
        .text("Missing days in dataset: " + missingDays8);

    // Calculate the 7-day moving average
    for (let i = 6; i < plotData8.length; i++) {

        let sum = 0;
        let validSevenDays = true;

        // Check the current day and previous six days
        for (let j = i - 6; j <= i; j++) {

            if (plotData8[j].pm25_city === null) {
                validSevenDays = false;
                break;
            }

            sum = sum + plotData8[j].pm25_city;
        }

        // Calculate average only if all seven days have readings
        if (validSevenDays) {
            plotData8[i].movingAverage = sum / 7;
        }
    }

    // Chart dimensions
    let width8 = 950;
    let height8 = 480;

    let margin8 = {
        top: 60,
        right: 40,
        bottom: 60,
        left: 70
    };

    // Create SVG
    let svg8 = d3.select("#chart-moving")
        .append("svg")
        .attr("viewBox", "0 0 " + width8 + " " + height8);

    // X scale: dates
    let x8 = d3.scaleTime()
        .domain([
            d3.timeDay.offset(startDate8, -0.5),
            d3.timeDay.offset(endDate8, 0.5)
        ])
        .range([margin8.left, width8 - margin8.right]);

    // Y scale: PM2.5 values
    let maxValue8 = d3.max(data, function(d) {
        return d.pm25_city;
    });

    let y8 = d3.scaleLinear()
        .domain([0, maxValue8])
        .nice()
        .range([height8 - margin8.bottom, margin8.top]);

    // Draw X axis
    svg8.append("g")
        .attr("transform", "translate(0," + (height8 - margin8.bottom) + ")")
        .call(d3.axisBottom(x8));

    // Draw Y axis
    svg8.append("g")
        .attr("transform", "translate(" + margin8.left + ",0)")
        .call(d3.axisLeft(y8));

    // X axis label
    svg8.append("text")
        .attr("x", width8 / 2)
        .attr("y", height8 - 10)
        .attr("text-anchor", "middle")
        .text("Date");

    // Y axis label
    svg8.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height8 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("PM2.5 (μg/m³)");

    // Find consecutive groups of missing dates
    let gapGroups8 = [];
    let currentGap8 = null;

    plotData8.forEach(function(d) {

        if (d.pm25_city === null) {

            if (currentGap8 === null) {
                currentGap8 = {
                    start: d.date,
                    end: d.date
                };
            }
            else {
                currentGap8.end = d.date;
            }

        }
        else if (currentGap8 !== null) {
            gapGroups8.push(currentGap8);
            currentGap8 = null;
        }

    });

    // Include a missing-data group if it reaches the final date
    if (currentGap8 !== null) {
        gapGroups8.push(currentGap8);
    }

    // Shade missing-data gaps
    gapGroups8.forEach(function(gap) {

        let gapStart = d3.timeDay.offset(gap.start, -0.5);
        let gapEnd = d3.timeDay.offset(gap.end, 0.5);

        let left = x8(gapStart);
        let right = x8(gapEnd);

        svg8.append("rect")
            .attr("x", left)
            .attr("y", margin8.top)
            .attr("width", right - left)
            .attr("height", height8 - margin8.top - margin8.bottom)
            .attr("fill", "#ffcccc")
            .attr("opacity", 0.6);

        // Label the missing-data gap
        svg8.append("text")
            .attr("x", (left + right) / 2)
            .attr("y", margin8.top + 20)
            .attr("text-anchor", "middle")
            .attr("font-size", "11px")
            .attr("fill", "#a00000")
            .text("No data: sensor offline");

    });

    // Line for daily PM2.5 readings
    let dailyLine8 = d3.line()
        .defined(function(d) {
            return d.pm25_city !== null;
        })
        .x(function(d) {
            return x8(d.date);
        })
        .y(function(d) {
            return y8(d.pm25_city);
        });

    // Draw daily readings
    svg8.append("path")
        .datum(plotData8)
        .attr("fill", "none")
        .attr("stroke", "#a6a6a6")
        .attr("stroke-width", 1)
        .attr("opacity", 0.7)
        .attr("d", dailyLine8);

    // Line for 7-day moving average
    let averageLine8 = d3.line()
        .defined(function(d) {
            return d.movingAverage !== null;
        })
        .x(function(d) {
            return x8(d.date);
        })
        .y(function(d) {
            return y8(d.movingAverage);
        });

    // Draw moving average
    svg8.append("path")
        .datum(plotData8)
        .attr("fill", "none")
        .attr("stroke", "#153e75")
        .attr("stroke-width", 3)
        .attr("d", averageLine8);

    // Legend: daily readings
    svg8.append("line")
        .attr("x1", width8 - 220)
        .attr("x2", width8 - 190)
        .attr("y1", 20)
        .attr("y2", 20)
        .attr("stroke", "#a6a6a6")
        .attr("stroke-width", 2);

    svg8.append("text")
        .attr("x", width8 - 180)
        .attr("y", 24)
        .text("Daily PM2.5");

    // Legend: moving average
    svg8.append("line")
        .attr("x1", width8 - 220)
        .attr("x2", width8 - 190)
        .attr("y1", 40)
        .attr("y2", 40)
        .attr("stroke", "#153e75")
        .attr("stroke-width", 3);

    svg8.append("text")
        .attr("x", width8 - 180)
        .attr("y", 44)
        .text("7-Day Average");

    // Print moving average results
    console.log("Task 8: 7-day moving average data:", plotData8);


        // =========================
    // TASK 9: INTERACTIVE ZOOM
    // =========================

    // Chart dimensions
    let width9 = 950;
    let height9 = 500;

    let margin9 = {
        top: 40,
        right: 40,
        bottom: 60,
        left: 70
    };

    // Overview chart dimensions
    let overviewHeight9 = 100;

    // Create SVG
    let svg9 = d3.select("#chart-zoom")
        .append("svg")
        .attr("viewBox", "0 0 " + width9 + " " + (height9 + 130));

    // Main chart scales
    let x9 = d3.scaleTime()
        .domain(d3.extent(data, function(d) {
            return d.date;
        }))
        .range([margin9.left, width9 - margin9.right]);

    let y9 = d3.scaleLinear()
        .domain([
            0,
            d3.max(data, function(d) {
                return d.pm25_city;
            })
        ])
        .nice()
        .range([height9 - margin9.bottom, margin9.top]);

    // Create main chart area
    let mainChart9 = svg9.append("g");

    // Draw main X axis
    let xAxis9 = mainChart9.append("g")
        .attr("transform", "translate(0," + (height9 - margin9.bottom) + ")");

    // Draw main Y axis
    mainChart9.append("g")
        .attr("transform", "translate(" + margin9.left + ",0)")
        .call(d3.axisLeft(y9));

    // X axis label
    mainChart9.append("text")
        .attr("x", width9 / 2)
        .attr("y", height9 - 10)
        .attr("text-anchor", "middle")
        .text("Date");

    // Y axis label
    mainChart9.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height9 / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .text("PM2.5 (μg/m³)");

    // Create line generator
    let line9 = d3.line()
        .x(function(d) {
            return x9(d.date);
        })
        .y(function(d) {
            return y9(d.pm25_city);
        });

    // Draw main chart line
    let mainLine9 = mainChart9.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", "#2468a2")
        .attr("stroke-width", 2);

    // Draw overview chart
    let overviewY9 = height9 + 30;

    let overviewXScale9 = d3.scaleTime()
        .domain(x9.domain())
        .range([margin9.left, width9 - margin9.right]);

    let overviewYScale9 = d3.scaleLinear()
        .domain(y9.domain())
        .range([overviewY9 + overviewHeight9, overviewY9]);

    let overviewLine9 = d3.line()
        .x(function(d) {
            return overviewXScale9(d.date);
        })
        .y(function(d) {
            return overviewYScale9(d.pm25_city);
        });

    // Draw overview line
    svg9.append("path")
        .datum(data)
        .attr("fill", "none")
        .attr("stroke", "#999")
        .attr("stroke-width", 1.5)
        .attr("d", overviewLine9);

    // Draw overview X axis
    svg9.append("g")
        .attr("transform", "translate(0," + (overviewY9 + overviewHeight9) + ")")
        .call(d3.axisBottom(overviewXScale9));

       // Brush selection
    let brush9 = d3.brushX()
        .extent([
            [margin9.left, overviewY9],
            [width9 - margin9.right, overviewY9 + overviewHeight9]
        ])
        .on("brush end", function(event) {

            if (event.selection) {

                let selectedDates = event.selection.map(function(value) {
                    return overviewXScale9.invert(value);
                });

                x9.domain(selectedDates);

            }
            else {
                x9.domain(overviewXScale9.domain());
            }

            // Update main chart line
            mainLine9.attr("d", line9);

            // Update X axis
            xAxis9.call(d3.axisBottom(x9));

        });

    // Add brush to overview chart
    let brushGroup9 = svg9.append("g")
        .attr("class", "brush")
        .call(brush9);

    // Select the entire year initially
    brushGroup9.call(
        brush9.move,
        [margin9.left, width9 - margin9.right]
    );

    // Reset button
    d3.select("#reset-zoom")
        .on("click", function() {

            brushGroup9.call(
                brush9.move,
                [margin9.left, width9 - margin9.right]
            );

        });


}).catch(function(error) {

    console.log("Error loading CSV:", error);

    d3.select("#results")
        .html("<p>Could not load the dataset. Check the file path and filename.</p>");

});
